<?php
class MCD
{
    public function calcularMCD($num1, $num2)
    {
        if ($num2 == 0) {
            return $num1;
        }
        echo $num2, $num1 % $num2;

        var_dump(
       $this->calcularMCD($num2, $num1 % $num2));
       die();   
    }
}

$mcd = new MCD();

$num1 = 18;
$num2 = 10;

$resultado = $mcd->calcularMCD($num1, $num2);

echo "El Máximo Común Divisor de $num1 y $num2 es: $resultado";










